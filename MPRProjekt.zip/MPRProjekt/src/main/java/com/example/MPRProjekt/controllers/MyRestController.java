package com.example.MPRProjekt.controllers;

import com.example.MPRProjekt.model.Capybara;
import com.example.MPRProjekt.services.CapybaraService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class MyRestController {
    private CapybaraService service;

    @Autowired
    public MyRestController(CapybaraService capybaraService) {
        this.service = capybaraService;
    }

    @GetMapping("capybara/all")
    public List<Capybara> getAll() {
        return this.service.getCapybaraList();
    }
    @GetMapping("capybara/{index}")
    public Capybara get(@PathVariable int index) {
        return this.service.get(index);
    }

    @PostMapping("capybara/all")
    public void  post(@RequestBody Capybara capybara) {
        this.service.create(capybara);
    }

    @DeleteMapping("capybara/all")
    public void  delete(@RequestBody Capybara capybara) {
        this.service.remove(capybara);
    }
}
