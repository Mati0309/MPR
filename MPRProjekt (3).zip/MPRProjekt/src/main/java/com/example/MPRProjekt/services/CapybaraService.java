package com.example.MPRProjekt.services;

import com.example.MPRProjekt.model.Capybara;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

//http://localhost:8080/capybara/all->strona
//clinet Api Hub chrome ustawienia Content-Type application/json
@Component
public class CapybaraService {
    private List<Capybara> capybaraList = new ArrayList<>();

    public CapybaraService() {
        this.capybaraList.add(new Capybara("Szymon", "brown"));
        this.capybaraList.add(new Capybara("Julia", "gray"));
        this.capybaraList.add(new Capybara("Witold", "beige"));
        this.capybaraList.add(new Capybara("Mateusz", "creme"));
    }

    public List<Capybara> getCapybaraList() {
        return this.capybaraList;
    }
    public Capybara get(int id) {
        return this.capybaraList.get(id);
    }
    public void create(Capybara capybara) {
         this.capybaraList.add(capybara);
    }
    public void remove(int id) {
        this.capybaraList.remove(id);
    }
    public void update(int id, Capybara capybara) {this.capybaraList.set(id,capybara);}
}
