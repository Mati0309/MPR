package com.example.MPRProjekt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MprProjektApplication {

	public static void main(String[] args) {
		SpringApplication.run(MprProjektApplication.class, args);
	}

}
